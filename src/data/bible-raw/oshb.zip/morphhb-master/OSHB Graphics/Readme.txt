OSHB Trademark Policy

The OSHB logo, icon, individual graphics and wording design are
trademarks of the Open Scriptures Hebrew Bible Project.  We license
their use in crediting or linking to our resources.

Copyright 2014, the Open Scriptures Hebrew Bible Project.